__author__ = 'xead'
from sklearn.externals import joblib
import functions as fu


class SentimentClassifier(object):
    def __init__(self):
        self.model = joblib.load("data/model.pkl")
        self.vectorizer = joblib.load("data/vectorizer.pkl")
        self.classes_dict = {0: "negative", 1: "positive", -1: "prediction error"}

    @staticmethod
    def get_probability_words(probability):
        if probability == 0:
            return "negative review"
        if probability == 1:
            return "positive review"


    def predict_text(self, text):
        try:
            vectorized = self.vectorizer.transform([fu.normalize_string2(text)])
            return self.model.predict(vectorized)
        except:
            print("prediction error")
            return -1, 0.8



    def get_prediction(self, text):
        prediction = self.predict_text(text)
        return self.get_probability_words(prediction)